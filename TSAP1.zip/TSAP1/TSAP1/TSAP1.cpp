// TSAP1.cpp : This file contains the 'main' function. Program execution begins and ends there.
/*
	Turing SAP 1 EPROM generator and emulator
	Copyright(C) 2022 Matthew Regan

	This program is free software : you can redistribute it and /or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.If not, see < https://www.gnu.org/licenses/>.
*/

#include <iostream>
#include <stdio.h>
#include <math.h>

#define     CF      1
#define     ZF      2

#define     RULES       0x400
#define     SYMBOLS     0x100

#define     RULE_RESET      0
#define     RULE_FETCH      1
#define     RULE_DECODE     2
#define     RULE_LDA        3
#define     RULE_ADD        21
#define     RULE_SUB        72
#define     RULE_STA        90
#define     RULE_LDI        108
#define     RULE_JC         125
#define     RULE_JZ         143
#define     RULE_JMP        161
#define     RULE_ADD8       178
#define     RULE_SETFLAGS   434
#define     RULE_OUT        438
#define     RULE_PROG       695

#define     AREG            0
#define     BREG            1
#define     SR              2
#define     IREG            3
#define     PC              4
#define     OREG            5
#define     EA              6

#define     MREAD           0x01
#define     MWRITE          0x02
#define     NOMEM           0x00
#define     NPREGS          0x10000
#define     CLOCK2          0x40000
#define     SRAMSIZE        0x20000
#define		EPROM27C1024	0x040000

unsigned int TuringROM[0x200000];
int		GenerateEPROM();

int maxRule = 0;

struct rule
{
    int next;
    unsigned char writeSymbol;
    unsigned char notePad;
    unsigned char output;
} ruleBook [RULES][SYMBOLS];

unsigned char notePad[SRAMSIZE];

unsigned char Fibonacci[16] = {
	0x51,			//	LDI
	0x4E,			//	STA
	0x50,			//	LDI
	0x2E,			//	ADD
	0x70,			//	JC
	0xE0,			//	OUT
	0x4F,			//	STA
	0x1E,			//	LDA
	0x4D,			//	STA
	0x1F,			//	LDA
	0x4E,			//	STA
	0x1D,			//	LDA
	0x63,			//	JMP 
	0x00,
	0x00,
	0x00
};

//	Data comes int assuming data signals are contiguous on the 27c322 ROM
//	Data goes out in the correct position on the chip
unsigned int SwizzleData(unsigned int val)
{
	unsigned int ret;

	ret = 0;
	for (int i = 0; i < 16; i++) {
		if (val & (1 << i)) ret |= ((i & 1) ? (1 << (((i & 14) >> 1) + 8)) : (1 << ((i >> 1))));
	}
	for (int i = 16; i < 32; i++) {
		if (val & (1 << i)) ret |= ((i & 1) ? (1 << (((i & 14) >> 1) + 24)) : (1 << ((((i & 14) >> 1)) + 16)));
	}
	return ret;
}

//	Data in the correct position on the chip
//	Data goes out assuming data signals are contiguous on the 27c322 ROM
//  The native pinout of the chip effectively performs the Deswizzle from pinout to circuit
unsigned int DeSwizzleData(unsigned int val)
{
	unsigned int ret;

	ret = 0;
	for (int i = 0; i < 16; i++) {
		if (val & (1 << i)) ret |= ((i & 8) ? (1 << (((i & 7) * 2) + 1)) : (1 << (i * 2)));
	}
	for (int i = 16; i < 32; i++) {
		if (val & (1 << i)) ret |= ((i & 8) ? (1 << (((i & 7) * 2) + 17)) : (1 << (((i & 7) * 2) + 16)));
	}
	return ret;
}

bool	SetRule(int rule, unsigned char readSymbol, int nextRule, unsigned char writeSymbol, unsigned char npLoc, unsigned char output)
{
	if (!((rule < RULES) && (nextRule < RULES))) return false;
	if (!((readSymbol < SYMBOLS) && (writeSymbol < SYMBOLS))) return false;

	ruleBook[rule][readSymbol].next = nextRule;
	ruleBook[rule][readSymbol].writeSymbol = writeSymbol;
	ruleBook[rule][readSymbol].notePad = npLoc;
	ruleBook[rule][readSymbol].output = output;
	return true;
}

bool	GetRule(int rule, unsigned char readSymbol, int* nextRule, unsigned char* writeSymbol, unsigned char* npLoc, unsigned char* output)
{
	if (!(rule < RULES)) return false;
	if (!(readSymbol < SYMBOLS)) return false;

	*nextRule		= ruleBook[rule][readSymbol].next;
	*writeSymbol	= ruleBook[rule][readSymbol].writeSymbol;
	*npLoc			= ruleBook[rule][readSymbol].notePad;
	*output			= ruleBook[rule][readSymbol].output;
	return true;
}

void		GenerateRuleBook()
{
	int rule, i, j;

	rule = RULE_RESET;
	for (i = 0; i < SYMBOLS; i++)		SetRule(rule, i, RULE_PROG, i, PC, NOMEM);

	rule = RULE_FETCH;
	for (i = 0; i < SYMBOLS; i++)		SetRule(rule, i, RULE_DECODE, (i+1)&0x0f, IREG, MREAD);

	rule = RULE_DECODE;
	for (i = 0; i < SYMBOLS; i++) {
		switch (i & 0xf0) {
		case 0x10:	SetRule(rule, i, RULE_LDA, i, IREG, NOMEM);			break;		//	LDA
		case 0x20:	SetRule(rule, i, RULE_ADD, i, IREG, NOMEM);			break;		//	ADD
		case 0x30:	SetRule(rule, i, RULE_SUB, i, IREG, NOMEM);			break;		//	SUB
		case 0x40:	SetRule(rule, i, RULE_STA, i, IREG, NOMEM);			break;		//	STA
		case 0x50:	SetRule(rule, i, RULE_LDI, i, IREG, NOMEM);			break;		//	LDI
		case 0x60:	SetRule(rule, i, RULE_JMP, i, IREG, NOMEM);			break;		//	JMP
		case 0x70:	SetRule(rule, i, RULE_JC, i, SR, NOMEM);			break;		//	JC
		case 0x80:	SetRule(rule, i, RULE_JZ, i, SR, NOMEM);			break;		//	JZ
		case 0xE0:	SetRule(rule, i, RULE_OUT, i, AREG, NOMEM);			break;		//	OUT
		case 0xF0:	SetRule(rule, i, RULE_DECODE, i, IREG, NOMEM);		break;		//	HLT
		default:	SetRule(rule, i, RULE_FETCH, i, PC, NOMEM);			break;		//	NOP
		}
	}

	//	LDA
	rule = RULE_LDA;
	for (i = 0; i < SYMBOLS; i++)		SetRule(rule, i, rule + 1 + (i & 0x0f), i, EA, NOMEM);
	rule++;
	for (j = 0; j < 16; j++, rule++) {
		for (i = 0; i < SYMBOLS; i++)   SetRule(rule, i, RULE_LDA + 17, j, AREG, MREAD);
	}
	for (i = 0; i < SYMBOLS; i++)		SetRule(rule, i, RULE_FETCH, i, PC, NOMEM);

	//	STA
	rule = RULE_STA;
	for (i = 0; i < SYMBOLS; i++)		SetRule(rule, i, rule + 1 + (i & 0x0f), i, EA, NOMEM);
	rule++;
	for (j = 0; j < 16; j++, rule++) {
		for (i = 0; i < SYMBOLS; i++)   SetRule(rule, i, RULE_STA + 17, j, AREG, NOMEM);
	}
	for (i = 0; i < SYMBOLS; i++)		SetRule(rule, i, RULE_FETCH, i, PC, MWRITE);

	rule = RULE_LDI;
	for (i = 0; i < SYMBOLS; i++)		SetRule(rule, i, rule + 1 + (i & 0x0f), i, AREG, NOMEM);
	rule++;
	for (j = 0; j < 16; j++, rule++) {
		for (i = 0; i < SYMBOLS; i++)   SetRule(rule, i, RULE_FETCH, j, PC, NOMEM);
	}

	//	JC
	rule = RULE_JC;
	for (i = 0; i < SYMBOLS; i++) {
		if (i & CF)	SetRule(rule, i, RULE_JMP, i, IREG, NOMEM);
		else SetRule(rule, i, RULE_FETCH, i, PC, NOMEM);
	}

	//	JZ
	rule = RULE_JZ;
	for (i = 0; i < SYMBOLS; i++) {
		if (i & ZF)	SetRule(rule, i, RULE_JMP, i, IREG, NOMEM);
		else SetRule(rule, i, RULE_FETCH, i, PC, NOMEM);
	}

	//	JMP
	rule = RULE_JMP;
	for (i = 0; i < SYMBOLS; i++)		SetRule(rule, i, rule + 1 + (i & 0x0f), i, PC, NOMEM);
	rule++;
	for (j = 0; j < 16; j++, rule++) {
		for (i = 0; i < SYMBOLS; i++)   SetRule(rule, i, RULE_DECODE, j, IREG, MREAD);
	}

	//	ADD
	rule = RULE_ADD;
	for (i = 0; i < SYMBOLS; i++)		SetRule(rule, i, rule + 1 + (i & 0x0f), i, EA, NOMEM);
	rule++;
	for (j = 0; j < 16; j++, rule++) {
		for (i = 0; i < SYMBOLS; i++)   SetRule(rule, i, RULE_ADD + 17, j, BREG, MREAD);
	}
	for (i = 0; i < SYMBOLS; i++)		SetRule(rule, i, RULE_ADD8 + i, i, AREG, NOMEM);

	//	Perform 8-bit ADD
	rule = RULE_ADD8;
	for (j = 0; j < SYMBOLS; j++, rule++) {
		for (i = 0; i < SYMBOLS; i++) {
			int temp = i + j;
			int zero = (temp & 0xff) ? 0 : ZF;
			int carry = (temp & 0x100) ? CF : 0;

			SetRule(rule, i, RULE_SETFLAGS + 2 * zero + carry, temp & 0xFF, SR, NOMEM);
		}
	}

	//	Set Flags
	rule = RULE_SETFLAGS;
	for (i = 0; i < SYMBOLS; i++)	SetRule(rule, i, RULE_FETCH, (i & 0xfc) + 0, PC, NOMEM);
	rule++;
	for (i = 0; i < SYMBOLS; i++)	SetRule(rule, i, RULE_FETCH, (i & 0xfc) + CF, PC, NOMEM);
	rule++;
	for (i = 0; i < SYMBOLS; i++)	SetRule(rule, i, RULE_FETCH, (i & 0xfc) + ZF, PC, NOMEM);
	rule++;
	for (i = 0; i < SYMBOLS; i++)	SetRule(rule, i, RULE_FETCH, (i & 0xfc) + CF + ZF, PC, NOMEM);
	rule++;

	// SUB
	rule = RULE_SUB;
	for (i = 0; i < SYMBOLS; i++)		SetRule(rule, i, rule + 1 + (i & 0x0f), i, EA, NOMEM);
	rule++;
	for (j = 0; j < 16; j++, rule++) {
		for (i = 0; i < SYMBOLS; i++)   SetRule(rule, i, RULE_SUB + 17, j, BREG, MREAD);
	}
	for (i = 0; i < SYMBOLS; i++)		SetRule(rule, i, RULE_ADD8 + ((i^0xff)+1)&0xff, ((i ^ 0xff) + 1) & 0xff, AREG, NOMEM);

	rule = RULE_OUT;
	for (i = 0; i < SYMBOLS; i++)		SetRule(rule, i, rule + 1 + i, i, OREG, NOMEM);
	rule++;
	for (j = 0; j < SYMBOLS; j++, rule++) {
		for (i = 0; i < SYMBOLS; i++)   SetRule(rule, i, RULE_FETCH, j, PC, NOMEM);
	}

	//	Program the Fibonacci sequence on reset
	rule = RULE_PROG;
	for (i = 0; i < SYMBOLS; i++)		SetRule(rule, i, rule + 1, 0, AREG, NOMEM);
	rule++;
	for (j = 0; j < 15; j++) {
		for (i = 0; i < SYMBOLS; i++)   SetRule(rule, i, rule + 1, Fibonacci[j], PC, MWRITE);
		rule++;
		for (i = 0; i < SYMBOLS; i++)   SetRule(rule, i, rule + 1, i+1, AREG, NOMEM);
		rule++;
	}
	for (i = 0; i < SYMBOLS; i++)   SetRule(rule, i, rule + 1, Fibonacci[j], PC, MWRITE);
	rule++;
	for (i = 0; i < SYMBOLS; i++)   SetRule(rule, i, RULE_FETCH, 0x0f, PC, NOMEM);
	rule++;

	maxRule = rule;
	GenerateEPROM();
	return;
}

//		Deswizzles the addressing and data used by the 27C322
bool	GetRuleFromROM(int rule, unsigned char readSymbol, int* nextRule, unsigned char* writeSymbol, unsigned char* npLoc, unsigned char* output)
{

	if (!(rule < RULES)) return false;
	if (!(readSymbol < SYMBOLS)) return false;
	unsigned char symbol = readSymbol;
	unsigned int upper = 0, lower = 0;

	//	compute the address
	unsigned int address = 0;
	for (int i = 0; i < 8; i++) if (rule & (1 << (7 - i))) address |= (1 << i);
	for (int i = 0; i < 7; i++) {
		if (symbol & (1 << (6 - i))) address |= (1 << (i + 8));
	}
	//	W7 is connected to A19
	if (symbol & 0x80) address |= 0x80000;
	//	Rule bit 8 is connected to A16
	if (rule & 0x100)  address |= 0x10000;
	//	Rule bit 9 is connected to A15
	if (rule & 0x200)  address |= 0x08000;

	lower = DeSwizzleData(TuringROM[address]);
	upper = DeSwizzleData(TuringROM[address + CLOCK2]);

	*output = 0;
	if (upper & 0x2000) *output |= MREAD;
	if (upper & 0x1000) *output |= MWRITE;

	*nextRule = upper & 0x3ff;
	*writeSymbol = (lower >> 8) & 0x0ff;
	*npLoc = ((lower >> 4) & 0x0f) | ((lower & 0x01) ? 0x80 : 0x00) | ((lower & 0x02) ? 0x40 : 0x00);
	return true;
}

int		GenerateEPROM()
{
	for (int i = 0; i < 0x200000; i++) TuringROM[i] = 0x00;


	for (int rule = 0; rule < maxRule; rule++) {
		for (int symbol = 0; symbol < SYMBOLS; symbol++) {
			unsigned int upper = 0, lower = 0;

			//	compute the address, this corrects for the fact that i didn't use contiguous address pins
			unsigned int address = 0;
			for (int i = 0; i < 8; i++) if (rule & (1 << (7 - i))) address |= (1 << i);
			for (int i = 0; i < 7; i++) if (symbol & (1 << (6 - i))) address |= (1 << (i + 8));
			//	W7 is connected to A19
			if (symbol & 0x80) address |= 0x80000;
			//	Rule bit 8 is connected to A16
			if (rule & 0x100)  address |= 0x10000;
			//	Rule bit 9 is connected to A15
			if (rule & 0x200)  address |= 0x08000;

			unsigned char np = ruleBook[rule][symbol].notePad;

			upper = ruleBook[rule][symbol].next;
			lower = ((ruleBook[rule][symbol].writeSymbol) << 8) | (np << 4);

			//	Generate Read, Write, ReadBar and WriteBar signal.	
			int output = ruleBook[rule][symbol].output;
			//	SET MREAD, MWRITE, MREADBAR and MWRITEBAR bits
			if (output & MREAD) upper |= 0x2000;
			else upper |= 0x8000;
			if (output & MWRITE) upper |= 0x1000;
			else upper |= 0x4000;

			//	Clock the various registers.
			if (!(np == OREG)) lower |= 0x02;
			if (!((np == PC) || (np == EA))) lower |= 0x01;

			TuringROM[address] = SwizzleData(lower);
			TuringROM[address + CLOCK2] = SwizzleData(upper);

		}
	}

	//	We need to write 8 files to program the 27C322.
	//	Using a TL866 with an adaptor board, we program 
	//	it with 8 different files in 27C1024 mode
	for (int i = 0; i < 8; i++) { 
		FILE* rom;
		char fname[256];
		sprintf_s(fname, "TuringSAP_ROM%d", i);
		fopen_s(&rom, fname, "w+b");
		for (int j = 0; j < EPROM27C1024; j++) {
			fputc(TuringROM[i * EPROM27C1024 + j] & 0xff, rom);
			fputc((TuringROM[i * EPROM27C1024 + j] >> 8) & 0xff, rom);
		}
		fclose(rom);
	}
	return 1;
}

int		nextRule;
unsigned char readSymbol;
unsigned char writeSymbol;
unsigned char nextNotePad;
//	Starting conditions
unsigned char notePadLocation = 0xc0 | PC;
unsigned char MAR = 0;
unsigned char output = NOMEM;
int ruleNo;
int main()
{
	GenerateRuleBook();
	for (int count = 0; count < 10000; count++) {
		readSymbol = notePad[(output & MREAD) ? (MAR) : (NPREGS + (notePadLocation & 0x0f))];
//		GetRule (ruleNo, readSymbol, &nextRule, &writeSymbol, &nextNotePad, &output);		
		GetRuleFromROM(ruleNo, readSymbol, &nextRule, &writeSymbol, &nextNotePad, &output);
		notePad[(output & MWRITE) ? (MAR) : (NPREGS + (notePadLocation & 0x0f))] = writeSymbol;
		if (!(notePadLocation & 0x40)) {
			fprintf_s(stderr, "Output = %d\n", writeSymbol);
		}
		if (!(notePadLocation & 0x80)) MAR = writeSymbol;
		notePadLocation = nextNotePad;
		ruleNo = nextRule;
	}
	return 1;
}

